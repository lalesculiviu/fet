//
//
// Description: This file is part of FET
//
//
// Author: Liviu Lalescu (Please see https://lalescu.ro/liviu/ for details about contacting Liviu Lalescu (in particular, you can find there the email address))
// Copyright (C) 2013 Liviu Lalescu <https://lalescu.ro/liviu/>
//
/***************************************************************************
 *                                                                         *
 *   This program is free software: you can redistribute it and/or modify  *
 *   it under the terms of the GNU Affero General Public License as        *
 *   published by the Free Software Foundation, version 3 of the License.  *
 *                                                                         *
 ***************************************************************************/

#include "messageboxes.h"

#include <iostream>

#include <QDir>
#include <QFile>
#include <QTextStream>

#include <QCoreApplication>

#include "longtextmessageboxcl.h"

extern QString logsDir; //computed in fet.cpp

void commandLineMessage(QWidget* parent, const QString& title, const QString& message,
 bool isWarning, bool isError)
{
	Q_UNUSED(parent);
	
	assert((isWarning && !isError) || (!isWarning && isError));
	
	QString filename;
	if(isWarning)
		filename=logsDir+"warnings.txt";
	else
		filename=logsDir+"errors.txt";
	
	bool begin;
	if(QFile::exists(filename))
		begin=false;
	else
		begin=true;

	QFile file(filename);
	
#if QT_VERSION >= QT_VERSION_CHECK(6,0,0)
	if(!file.open(QIODeviceBase::Append)){
#else
	if(!file.open(QIODevice::Append)){
#endif
		std::cout<<"FET critical - you don't have write permissions in the output directory - (FET cannot open or create file "<<qPrintable(QDir::toNativeSeparators(filename))<<")."
			 " If this is a bug - please report it."<<std::endl;
		return;
	}
	QTextStream tos(&file);
#if QT_VERSION >= QT_VERSION_CHECK(6,0,0)
	tos.setEncoding(QStringConverter::Utf8);
#else
	tos.setCodec("UTF-8");
#endif
	if(begin){
		tos.setGenerateByteOrderMark(true);
	}
	
	tos<<QCoreApplication::translate("FetCommandLine", "Title: %1").arg(title)<<Qt::endl;
	tos<<QCoreApplication::translate("FetCommandLine", "Message: %1").arg(message)<<Qt::endl;
	tos<<Qt::endl;
	
	if(file.error()!=QFileDevice::NoError){
		std::cout<<"FET critical - writing in the file "<<qPrintable(QDir::toNativeSeparators(filename))<<" gave the error message "
			 <<qPrintable(file.errorString())<<" which means the writing is compromised. Please check your disk's free space."<<std::endl;
	}
	file.close();
}

int commandLineMessage(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text, int defaultButton, int escapeButton,
 bool isWarning, bool isError)
{
	Q_UNUSED(parent);

	assert((isWarning && !isError) || (!isWarning && isError));
	
	QString filename;
	if(isWarning)
		filename=logsDir+"warnings.txt";
	else
		filename=logsDir+"errors.txt";
	
	bool begin;
	if(QFile::exists(filename))
		begin=false;
	else
		begin=true;

	QFile file(filename);
	
#if QT_VERSION >= QT_VERSION_CHECK(6,0,0)
	if(!file.open(QIODeviceBase::Append)){
#else
	if(!file.open(QIODevice::Append)){
#endif
		std::cout<<"FET critical - you don't have write permissions in the output directory - (FET cannot open or create file "<<qPrintable(QDir::toNativeSeparators(filename))<<")."
			 " If this is a bug - please report it."<<std::endl;
		return defaultButton;
	}
	QTextStream tos(&file);
#if QT_VERSION >= QT_VERSION_CHECK(6,0,0)
	tos.setEncoding(QStringConverter::Utf8);
#else
	tos.setCodec("UTF-8");
#endif
	if(begin){
		tos.setGenerateByteOrderMark(true);
	}
	
	tos<<QCoreApplication::translate("FetCommandLine", "Title: %1").arg(title)<<Qt::endl;
	tos<<QCoreApplication::translate("FetCommandLine", "Message: %1").arg(message)<<Qt::endl;

	if(button0Text!=QString())
		tos<<QCoreApplication::translate("FetCommandLine", "Button 0 text: %1").arg(button0Text)<<Qt::endl;
	if(button1Text!=QString())
		tos<<QCoreApplication::translate("FetCommandLine", "Button 1 text: %1").arg(button1Text)<<Qt::endl;
	if(button2Text!=QString())
		tos<<QCoreApplication::translate("FetCommandLine", "Button 2 text: %1").arg(button2Text)<<Qt::endl;

	tos<<QCoreApplication::translate("FetCommandLine", "Default button: %1").arg(defaultButton)<<Qt::endl;
	tos<<QCoreApplication::translate("FetCommandLine", "Escape button: %1").arg(escapeButton)<<Qt::endl;

	tos<<QCoreApplication::translate("FetCommandLine", "Pressing default button %1").arg(defaultButton)<<Qt::endl;
	
	tos<<Qt::endl;
	
	if(file.error()!=QFileDevice::NoError){
		std::cout<<"FET critical - writing in the file "<<qPrintable(QDir::toNativeSeparators(filename))<<" gave the error message "
			 <<qPrintable(file.errorString())<<" which means the writing is compromised. Please check your disk's free space."<<std::endl;
	}
	file.close();
	
	return defaultButton;
}

//Rules

int RulesConstraintIgnored::mediumConfirmation(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

void RulesImpossible::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

void RulesReconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

int RulesReconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

int RulesReconcilableMessage::mediumConfirmation(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

void RulesReconcilableMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

int RulesReconcilableMessage::information(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

void RulesIrreconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

/*int RulesIrreconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton);
}*/

void RulesUsualInformation::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

void RulesReadingWrongConstraint::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

void IrreconcilableCriticalMessage::critical(QWidget* parent, const QString& title, const QString& message)
{
	commandLineMessage(parent, title, message, false, true);
}

//GeneratePre

int GeneratePreReconcilableMessage::mediumConfirmation(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

int GeneratePreReconcilableMessage::largeConfirmation(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::largeConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

void GeneratePreReconcilableMessage::largeInformation(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::largeInformation(parent, title, message, true, false);
}

void GeneratePreIrreconcilableMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

int GeneratePreIrreconcilableMessage::information(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, false, true);
}

void GeneratePreIrreconcilableMessage::mediumInformation(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

int GeneratePreIrreconcilableMessage::mediumConfirmation(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, false, true);
}

//TimetableExport

int TimetableExportMessage::information(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

int TimetableExportMessage::warning(QWidget* parent, const QString& title, const QString& message,
 const QString& button0Text, const QString& button1Text, const QString& button2Text,
 int defaultButton, int escapeButton)
{
	return LongTextMessageBox::mediumConfirmation(parent, title, message, button0Text, button1Text, button2Text,
	 defaultButton, escapeButton, true, false);
}

void TimetableExportMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

void TimetableExportMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

//TimeConstraint

void TimeConstraintIrreconcilableMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

void TimeConstraintIrreconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

//SpaceConstraint

void SpaceConstraintIrreconcilableMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

void SpaceConstraintIrreconcilableMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, false, true);
}

//Fet

void FetMessage::information(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

void FetMessage::warning(QWidget* parent, const QString& title, const QString& message)
{
	LongTextMessageBox::mediumInformation(parent, title, message, true, false);
}

//QProgressDialog

EngineProgressDialog::EngineProgressDialog(QWidget* parent)
{
	Q_UNUSED(parent);
	qpd=nullptr;
}

EngineProgressDialog::~EngineProgressDialog()
{
	assert(qpd==nullptr);
}

void EngineProgressDialog::setWindowTitle(const QString& title)
{
	if(VERBOSE){
		std::cout<<qPrintable(QCoreApplication::translate("FetCommandLine", "Progress title: %1").arg(title))<<std::endl;
	}
}

void EngineProgressDialog::setLabelText(const QString& label)
{
	if(VERBOSE){
		std::cout<<qPrintable(QCoreApplication::translate("FetCommandLine", "Progress label: %1").arg(label))<<std::endl;
	}
}

void EngineProgressDialog::setRange(int a, int b)
{
	if(VERBOSE){
		std::cout<<qPrintable(QCoreApplication::translate("FetCommandLine", "Progress range: %1..%2").arg(a).arg(b))<<std::endl;
	}
}

void EngineProgressDialog::setModal(bool m)
{
	if(VERBOSE){
		if(m)
			std::cout<<qPrintable(QCoreApplication::translate("FetCommandLine", "Progress setModal(true)"))<<std::endl;
		else
			std::cout<<qPrintable(QCoreApplication::translate("FetCommandLine", "Progress setModal(false)"))<<std::endl;
	}
}

void EngineProgressDialog::setValue(int v)
{
	Q_UNUSED(v);
	//cout<<qPrintable(FetCommandLine::tr("Progress value: %1").arg(v))<<endl;
}

bool EngineProgressDialog::wasCanceled()
{
	return false;
}
