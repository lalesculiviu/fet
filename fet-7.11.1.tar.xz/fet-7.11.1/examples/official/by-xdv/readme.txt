https://lalescu.ro/liviu/fet/forum/index.php?topic=6970.0
