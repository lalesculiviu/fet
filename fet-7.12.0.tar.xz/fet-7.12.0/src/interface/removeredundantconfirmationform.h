//
//
// Description: This file is part of FET
//
//
// Author: Liviu Lalescu (Please see https://lalescu.ro/liviu/ for details about contacting Liviu Lalescu (in particular, you can find there the email address))
// Copyright (C) 2003 Liviu Lalescu <https://lalescu.ro/liviu/>
//
/***************************************************************************
 *                                                                         *
 *   This program is free software: you can redistribute it and/or modify  *
 *   it under the terms of the GNU Affero General Public License as        *
 *   published by the Free Software Foundation, version 3 of the License.  *
 *                                                                         *
 ***************************************************************************/

#ifndef REMOVEREDUNDANTCONFIRMATIONFORM_H
#define REMOVEREDUNDANTCONFIRMATIONFORM_H

#include "ui_removeredundantconfirmationform_template.h"

class RemoveRedundantConfirmationForm: public QDialog, Ui::RemoveRedundantConfirmationForm_template
{
	Q_OBJECT

public:
	bool dontShowAgain;

	RemoveRedundantConfirmationForm(QWidget* parent);
	~RemoveRedundantConfirmationForm();

public Q_SLOTS:
	void dontShowAgainCheckBoxToggled();
};

#endif
