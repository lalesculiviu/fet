2026-03-14: These examples include the exams constraints: room(s) max activities per teacher and building(s) min one activity in each available time slot.
