https://lalescu.ro/liviu/fet/forum/index.php?topic=7020.0

As my first post on the forum, I'm happy to share a hard but solvable timetable, which might be useful for testing purposes.

Besides various common constraints to lower gaps and optimise subject distribution, the main feature of this timetable are the activities with Subject29:
they spread over four specific hours and involve more than half of the available teachers, leaving just enough free teachers to cover the remaining groups.
I believe this is the most challenging part of the setup.

I was able to get valid solutions, in a reproducible way, by a mix of the following "hints" to the algorithm:

    ignore constraints under 100%;
    high bounds for teachers max gaps and max hours continuously;
    custom initial order.

From one iteration to the next, constraints were gradually refined to the desired parameters, and after eight subsequent generations, lasting around 30 minutes
each, a final result was produced.

The attached file has been edited to hide sensitive information.

Build: FET 7.8.4 for GNU/Linux.
