They take long, 10-60 minutes.
