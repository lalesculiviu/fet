The files with "early" will solve identically on FET-5.32.3 and FET-5.33.1.

It seems that for the "no_early" FET-5.33.1 is better than FET-5.32.3 (maybe two times faster, FET-5.33.1 solved 5 timetables while FET-5.32.3 only 2).
