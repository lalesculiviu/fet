kgerm-3.fet is very useful, helped me to find a critical cycling bug - 2019-11-17

k5-new.fet sometimes does not solve (goes to 86/400).
