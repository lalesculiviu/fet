2019-11-19: It seems that kgerm12.fet and kgerm13.fet sometimes do not solve.
