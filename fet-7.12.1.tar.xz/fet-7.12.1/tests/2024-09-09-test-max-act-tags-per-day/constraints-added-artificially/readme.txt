Start random seed 1,0,0, 1,0,0:

old (bad): 8m 46s,
new (good): 4m 29s.
