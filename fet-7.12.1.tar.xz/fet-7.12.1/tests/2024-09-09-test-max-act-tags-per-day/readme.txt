I think 3 and 4 do not solve, stop at 533/589.
