2026-11-10:

These test files were initially created by the FET authors or by different FET users, and were subsequently modified/adapted
as needed, to create interesting test cases for new constraints or features. They are copyright by the FET authors and
licensed under the GNU Free Documentation License Version 1.3.

If you use them for testing FET, you should also consider using the real-life examples (found in the fet-v.v.v/examples directory).

Note that some test files might be incorrect or unsolvable.
