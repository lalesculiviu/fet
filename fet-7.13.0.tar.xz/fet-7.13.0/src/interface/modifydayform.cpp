//
//
// Description: This file is part of FET
//
//
// Author: Liviu Lalescu (Please see https://lalescu.ro/liviu/ for details about contacting Liviu Lalescu (in particular, you can find there the email address))
// Copyright (C) 2024 Liviu Lalescu <https://lalescu.ro/liviu/>
//
/***************************************************************************
 *                                                                         *
 *   This program is free software: you can redistribute it and/or modify  *
 *   it under the terms of the GNU Affero General Public License as        *
 *   published by the Free Software Foundation, version 3 of the License.  *
 *                                                                         *
 ***************************************************************************/

#include "modifydayform.h"

#include "utilities.h"

ModifyDayForm::ModifyDayForm(QWidget* parent, const QString& name, const QString& longName): QDialog(parent)
{
	setupUi(this);
	
	centerWidgetOnScreenAndOtherThings(this);
	restoreFETDialogGeometry(this);
	
	nameLineEdit->setText(name);
	longNameTextEdit->setPlainText(longName);
	
	nameLineEdit->selectAll();
	nameLineEdit->setFocus();
	
	connect(okPushButton, &QPushButton::clicked, this, &ModifyDayForm::ok);
	connect(cancelPushButton, &QPushButton::clicked, this, &ModifyDayForm::cancel);
	
	okPushButton->setDefault(true);
}

ModifyDayForm::~ModifyDayForm()
{
	saveFETDialogGeometry(this);
}

void ModifyDayForm::ok()
{
	name=nameLineEdit->text();
	longName=longNameTextEdit->toPlainText();
	
	this->accept();
}

void ModifyDayForm::cancel()
{
	this->reject();
}
